Louis Segond 1910 French Bible data for Kingdom Life
=====================================================

Source: eBible.org French Louis Segond 1910 USFM archive (fraLSG_usfm.zip).
The included source archive's copr.htm identifies this Bible as Public Domain:
"Cette Bible est dans le domaine public. Il n'est pas protégé par copyright.
This Bible is in the Public Domain. It is not copyrighted."

Source page: https://ebible.org/Scriptures/details.php?id=fraLSG
eBible.org French edition page: https://ebible.org/fraLSG/

Files:
- 66 JSON files, one per Bible book, using the chapter -> verse -> text shape
  expected by Kingdom Life's existing showBibleChapter() reader.
- Folder name is intended to be `lsg1910` under `app/src/main/assets/`.

Notes:
- The USFM files were converted to JSON, preserving verse text and removing
  formatting markup, cross-reference notes, and editorial headings.
- Please retain this README/source attribution with the app's data.
- This package only contains data files; it does not change Java code or make
  French selectable in the reader by itself.
